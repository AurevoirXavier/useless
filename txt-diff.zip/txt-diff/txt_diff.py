import os
from shutil import copyfile
check_name = True
fields = [0 for _ in range(15)]
fields_name = ['name', 'phone', 'mail', 'duration1', 'school1', 'department1', 'major1', 'duration2', 'school2', 'department2', 'major2', 'duration3', 'school3', 'department3', 'major3']
if not os.path.isdir('error'): os.mkdir('error')
for name in fields_name:
    if not os.path.isdir(f'error/{name}'): os.mkdir(f'error/{name}')
# TODO 判断文件是否存在
with open('all.txt', 'r') as f:
    data = ''
    while True:
        line = f.readline()
        if check_name:
            num = line.strip()[-8:-4]
            check_name = True if line.isspace() else False
            continue
        if (line.isspace() or not line) and num:
            # TODO 判断文件是否存在
            with open(f'all/{num}.txt', 'r') as cmp_f:
                data = data.strip().splitlines()
                cmp_data = cmp_f.read().strip().splitlines()
                for i in range(15):
                    if data[i] == cmp_data[i]: fields[i] += 1
                    else:
                        # TODO 判断文件是否存在
                        copyfile(f'all/{num}.jpg', f'error/{fields_name[i]}/{num}_{data[i]}_{cmp_data[i]}.jpg')
            check_name = True
            data = ''
            continue
        if not line: break
        data += line
# TODO 输出美化
print(fields)
